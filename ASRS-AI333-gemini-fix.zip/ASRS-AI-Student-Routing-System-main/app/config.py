"""Read only the project's approved settings from a local, git-ignored .env file."""
import os
from pathlib import Path

ALLOWED = {"AI_ROUTER", "GEMINI_API_KEY", "GEMINI_MODEL", "GEMINI_TIMEOUT_SECONDS",
           "SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASSWORD", "SMTP_FROM", "SMTP_STARTTLS"}


def load_env(root):
    path = Path(root) / ".env"
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        name, value = name.strip(), value.strip()
        if name not in ALLOWED:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        # No evaluation, interpolation, subprocesses or arbitrary environment keys.
        # An existing non-empty variable wins; an empty one (common on Windows) must not hide the .env value.
        if not os.environ.get(name, "").strip():
            os.environ[name] = value
