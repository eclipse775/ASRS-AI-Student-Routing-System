---
name: User story
about: Track a source story or refinement
title: "US: "
labels: enhancement
---

## User and benefit

As a ..., I want ..., so that ...

## Scope and source

Story ID, sprint, source effort, priority, dependencies, owner.

## Acceptance

- Given ..., when ..., then ...

## Tasks

- [ ] Design and implementation
- [ ] Acceptance/security checks
- [ ] Documentation and evidence
- [ ] Actual Product Owner review
