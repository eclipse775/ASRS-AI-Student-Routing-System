## Resulting behavior

Describe the concrete trigger and result. Link the story and acceptance criteria.

## Validation

Record actual checks and their results. Separate local tests from CI execution.

## Review

State material limitations, changed assumptions, and any Product Owner decision still needed.
